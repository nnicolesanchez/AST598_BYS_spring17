Astronomy 598: Machine Learning (Winter 2017)
Student: Natalie Nicole Sanchez
Using Python 3.5.2
___________________________

To run program: coinflip.py
You will run "python coinflip.py"

Limitations: You are unable to vary the choice of M 
	     from outside the script.

Part a: What is the name of the probability distribution of heads?
Bernoulli distribution

Part b: Write choice of M: 100

Part c: At smaller N values, the distribution almost looks gaussian, but at larger N, the distribution begins to look bimodal.
